import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Smart Task Manager");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        TaskManager manager = new TaskManager();

        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> taskList = new JList<>(listModel);

        JTextField titleField = new JTextField(15);
        JTextField categoryField = new JTextField(10);
        String[] priorities = { "High", "Medium", "Low" };
        JComboBox<String> priorityBox = new JComboBox<>(priorities);

        JButton addBtn = new JButton("Add Task");
        JButton deleteBtn = new JButton("Delete Task");
        JButton loadBtn = new JButton("Load");
        JButton saveBtn = new JButton("Save");
        JButton markBtn = new JButton("Mark Completed");

        addBtn.addActionListener(e -> {
            String t = titleField.getText();
            String c = categoryField.getText();
            String p = priorityBox.getSelectedItem().toString();

            Task task = new Task(t, c, p);
            manager.addTask(task);
            listModel.addElement(task.toString());
        });

        deleteBtn.addActionListener(e -> {
            int i = taskList.getSelectedIndex();
            if (i != -1) {
                manager.deleteTask(i);
                listModel.remove(i);
            }
        });

        markBtn.addActionListener(e -> {
            int i = taskList.getSelectedIndex();
            if (i != -1) {
                manager.getTasks().get(i).setCompleted(true);
                listModel.set(i, manager.getTasks().get(i).toString());
            }
        });

        saveBtn.addActionListener(e -> {
            try {
                manager.saveTasks();
                JOptionPane.showMessageDialog(frame, "Tasks Saved!");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        loadBtn.addActionListener(e -> {
            try {
                manager.loadTasks();
                listModel.clear();
                for (Task t : manager.getTasks()) {
                    listModel.addElement(t.toString());
                }
                JOptionPane.showMessageDialog(frame, "Tasks Loaded!");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Category:"));
        panel.add(categoryField);
        panel.add(new JLabel("Priority:"));
        panel.add(priorityBox);
        panel.add(addBtn);

        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(taskList), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        bottom.add(markBtn);
        bottom.add(deleteBtn);
        bottom.add(saveBtn);
        bottom.add(loadBtn);

        frame.add(bottom, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}