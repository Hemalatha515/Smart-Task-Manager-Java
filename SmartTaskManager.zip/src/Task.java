public class Task implements java.io.Serializable {
    private String title;
    private String category;
    private String priority;
    private boolean completed;

    public Task(String title, String category, String priority) {
        this.title = title;
        this.category = category;
        this.priority = priority;
        this.completed = false;
    }

    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getPriority() { return priority; }
    public boolean isCompleted() { return completed; }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    @Override
    public String toString() {
        return title + " | " + category + " | " + priority + (completed ? " | Done" : "");
    }
}