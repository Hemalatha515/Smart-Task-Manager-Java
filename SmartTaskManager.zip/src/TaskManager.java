import java.io.*;
import java.util.ArrayList;

public class TaskManager {
    private ArrayList<Task> tasks = new ArrayList<>();

    public void addTask(Task task) {
        tasks.add(task);
    }

    public void deleteTask(int index) {
        tasks.remove(index);
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }

    public void saveTasks() throws Exception {
        FileOutputStream fos = new FileOutputStream("tasks.dat");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(tasks);
        oos.close();
    }

    public void loadTasks() throws Exception {
        FileInputStream fis = new FileInputStream("tasks.dat");
        ObjectInputStream ois = new ObjectInputStream(fis);
        tasks = (ArrayList<Task>) ois.readObject();
        ois.close();
    }
}