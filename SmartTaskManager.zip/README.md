# Smart Task Manager (Java Swing)

A desktop application developed using Java Swing, OOP, and File Handling.

## Features
- Add, delete, and manage tasks
- Categorize tasks
- Priority levels
- Mark as completed
- Save and load tasks

## How to Run
```
cd src
javac *.java
java Main
```
